<?
session_destroy()
?>