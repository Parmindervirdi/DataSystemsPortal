<?php 
  ?>
  <a href="mailto:manish@simplygraphix.com?subject=Feedback for webdevelopersnotes.com&body=The Tips and Tricks section is great">Send me an email</a>
  
  <?
// Create the size of image or blank image 
//$image = imagecreate(1000, 600); 
  
// Set the background color of image 
//$background_color = imagecolorallocate($image, 179, 203, 255); 
  
// Set the text color of image 
//$text_color = imagecolorallocate($image, 255, 255, 255); 
  
// Function to create image which contains string. 
//imagestring($image, 5, 180, 100, "<a href="mailto:manish@simplygraphix.com?subject=Feedback for webdevelopersnotes.com&body=The Tips and Tricks section is great">Send me an email</a>" , $text_color); 
//imagestring($image, 3, 160, 120,  "A computer science portal", $text_color); 
  
//header("Content-Type: image/png"); 

//imagepng($image); 
//imagedestroy($image); 
  
  
  
?> 